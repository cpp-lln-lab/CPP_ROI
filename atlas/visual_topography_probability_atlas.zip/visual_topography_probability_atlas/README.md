# README

This contains a lighter version of the Wang retinotopic atlas : only the volume
data has been kept and a look up table was created.

Downloaded from: https://scholar.princeton.edu/napl/resources

To cite:

> Wang, L., Mruczek, R. E., Arcaro, M. J., & Kastner, S. (2015). Probabilistic
> Maps of Visual Topography in Human Cortex. Cerebral cortex (New York, N.Y. :
> 1991), 25(10), 3911–3931. https://doi.org/10.1093/cercor/bhu277

For surface based and freesurfer ROIs see the original atlasz (URL above) or for
example:

-   https://github.com/noahbenson/neuropythy

# Original readme

This zip file contains the probabilistic maps. There are several files:

1. MNI152_T1_1mm.nii.gz : MNI volume image
2. ROIfiles_Labeling.txt : Text file containing correspondance of numerical
   labels to visual field maps
3. subj_vol_all/ : Folder containing probability maps in MNI volume space.
4. subj_surf_all/ : Folder containing probability maps in icosahedron surface
   space (using SUMA's MapIcosahedron -ld 141).

The volume and surface folders each contain:

1. a maximum probability map e.g., maxprob*surf*{hemisphere}
2. a full probability map for each area:
   perc*VTPM_surf_roi{number}*{hemisphere}. See manuscript for details on these
   maps.

Last Update: 12/9/14. Probability Atlas v4
